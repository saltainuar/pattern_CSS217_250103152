package com.ecommerce;

/**
 * Subsystem 2: PaymentGateway.
 * Money is passed as primitive long cents: no autoboxing, no double rounding errors.
 */
public class PaymentGateway {

    private static final long LIMIT_CENTS = 200_000L;

    public boolean charge(String customerId, long amountCents) {
        System.out.println("[PaymentGateway] Charging " + format(amountCents)
                + " to customer: " + customerId);
        if (amountCents > LIMIT_CENTS) {
            System.out.println("[PaymentGateway] Declined: over limit");
            return false;
        }
        System.out.println("[PaymentGateway] Payment captured");
        return true;
    }

    static String format(long cents) {
        return "$" + (cents / 100) + "." + String.format("%02d", cents % 100);
    }
}
