package com.ecommerce;
public class NotificationService {
    public void sendReceipt(String customerId, long amountCents) {
        StringBuilder receipt = new StringBuilder(64)
                .append("Receipt: ").append(PaymentGateway.format(amountCents))
                .append(" for customer ").append(customerId);
        System.out.println("[NotificationService] " + receipt);
    }
}