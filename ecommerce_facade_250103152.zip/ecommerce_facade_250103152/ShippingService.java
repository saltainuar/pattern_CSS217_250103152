package com.ecommerce;

/** Subsystem 3: ShippingService. */
public class ShippingService {

    public void scheduleDelivery(String productId, String address) {
        System.out.println("[ShippingService] Delivery scheduled: " + productId + " -> " + address);
    }
}
