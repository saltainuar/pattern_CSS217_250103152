package com.ecommerce;

/**
 * Facade: gives clients one method, placeOrder(), and hides the 4-service workflow.
 * The workflow is fixed and always the same, so a plain class is enough:
 * no interface with a single implementation is needed (see README).
 */
public class CheckoutFacade {
    
    private final InventoryService inventory = new InventoryService();
    private final PaymentGateway payment = new PaymentGateway();
    private final ShippingService shipping = new ShippingService();
    private final NotificationService notification = new NotificationService();

    /**
     * @param amountCents total price in cents (primitive long, no boxing)
     * @return true if the whole workflow succeeded
     */
    public boolean placeOrder(String productId, String customerId, String address, long amountCents) {
        System.out.println("=== [CheckoutFacade] Starting order ===");

        if (!inventory.checkStock(productId)) {
            System.out.println("[CheckoutFacade] Aborting: out of stock");
            return false;
        }

        inventory.reserve(productId);

        if (!payment.charge(customerId, amountCents)) {
            inventory.release(productId);
            System.out.println("[CheckoutFacade] Aborting: payment declined");
            return false;
        }

        shipping.scheduleDelivery(productId, address);
        notification.sendReceipt(customerId, amountCents);

        System.out.println("=== [CheckoutFacade] Order completed ===");
        return true;
    }
}
