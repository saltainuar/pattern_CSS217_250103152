package com.ecommerce;

import java.util.HashMap;
import java.util.Map;

/**
 * Subsystem 1: InventoryService.
 * Concrete class on purpose: only one implementation exists (see README, checklist Q1).
 */
public class InventoryService {

    private final Map<String, Integer> stock = new HashMap<>();

    public InventoryService() {
        stock.put("Laptop-X1", 5);
        stock.put("Phone-Z2", 0); 
    }

    public boolean checkStock(String productId) {
        System.out.println("[InventoryService] Checking stock for item: " + productId);
        return stock.getOrDefault(productId, 0) > 0;
    }

    public void reserve(String productId) {
        stock.merge(productId, -1, Integer::sum);
        System.out.println("[InventoryService] Reserved 1 unit of: " + productId);
    }

    /** Compensation step: give the unit back if a later step (payment) fails. */
    public void release(String productId) {
        stock.merge(productId, 1, Integer::sum);
        System.out.println("[InventoryService] Reservation released for: " + productId);
    }
}
