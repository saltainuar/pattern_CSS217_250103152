package com.ecommerce;

/** Client: talks only to the Facade, never to the subsystems. */
public class OrderController {

    public static void main(String[] args) {
        CheckoutFacade checkout = new CheckoutFacade();

        run(checkout, "1. Success",          "Laptop-X1", "user_404", "123 Main St", 120_000L);
        run(checkout, "2. Out of stock",     "Phone-Z2",  "user_404", "123 Main St", 80_000L);
        run(checkout, "3. Payment declined", "Laptop-X1", "user_404", "123 Main St", 300_000L);
    }

    private static void run(CheckoutFacade c, String title, String item, String customer,
                            String address, long cents) {
        System.out.println("\n##### " + title + " #####");
        boolean ok = c.placeOrder(item, customer, address, cents);
        System.out.println("Client received: " + (ok ? "Order completed successfully!" : "Order failed."));
    }
}
